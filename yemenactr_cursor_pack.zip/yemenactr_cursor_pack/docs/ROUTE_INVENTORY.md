# Route Inventory

Purpose: a living map of every route and whether it passes production gates.

## Template

| Route | EN | AR | Auth required | Evidence coverage | Exports | Notes | Owner |
|---|---:|---:|---:|---:|---:|---|---|
| / | PASS/FAIL | PASS/FAIL | public/auth | % | PASS/FAIL | | |

