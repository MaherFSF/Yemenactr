# Decisions Log

Every time we pick a default (NULL vs default, backfill policy, tier mapping, etc.), log it here.

## Decision template

- **DECISION ID:** DEC-YYYYMMDD-XXX
- **Decision:**
- **Context:**
- **Options considered:**
- **Chosen option:**
- **Rationale:**
- **Risks & mitigations:**
- **Revisit trigger:**
- **Links:** PR / code / docs

---

