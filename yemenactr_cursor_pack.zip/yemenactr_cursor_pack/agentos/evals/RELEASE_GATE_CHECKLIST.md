# Release Gate Checklist (Eval)

For each release gate in docs/RELEASE_GATES.md:
- define: what to measure
- define: how to measure
- define: PASS threshold
- define: where it is rendered in /admin/release-gate

This is an evaluation document; it should be updated when gates evolve.
