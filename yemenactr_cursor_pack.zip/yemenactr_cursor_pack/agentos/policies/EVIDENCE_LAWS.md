# Evidence Laws

- Evidence-only: no metric without evidence.
- Provenance chain required for every observation.
- If missing: Gap Card + GAP ticket.
